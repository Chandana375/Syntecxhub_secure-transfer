﻿from flask import Flask,request,send_file
import os,jwt,logging

SECRET="supersecretkey"

app=Flask(__name__)

CHUNK_DIR="../storage/chunks"
FINAL_FILE="../storage/encrypted.bin"

os.makedirs(CHUNK_DIR,exist_ok=True)

logging.basicConfig(filename="server.log",level=logging.INFO,format="%(asctime)s %(message)s")

def verify_token(token):
    try:
        jwt.decode(token,SECRET,algorithms=["HS256"])
        return True
    except:
        return False

@app.route("/login")
def login():
    token=jwt.encode({"user":"client"},SECRET,algorithm="HS256")
    return {"token":token}

@app.route("/upload",methods=["POST"])
def upload():

    token=request.headers.get("token")

    if not verify_token(token):
        return {"error":"unauthorized"}

    chunk_id=request.args.get("chunk")

    file=request.files["file"]

    path=os.path.join(CHUNK_DIR,f"chunk_{chunk_id}")

    if os.path.exists(path):
        return {"status":"chunk exists"}

    data=file.read()

    if b"virus" in data.lower():
        logging.warning("malicious upload detected")
        return {"error":"malware detected"}

    with open(path,"wb") as f:
        f.write(data)

    logging.info(f"chunk {chunk_id} uploaded")

    return {"status":"chunk stored"}

@app.route("/assemble")
def assemble():

    with open(FINAL_FILE,"wb") as out:

        chunks=sorted(os.listdir(CHUNK_DIR))

        for c in chunks:

            with open(os.path.join(CHUNK_DIR,c),"rb") as f:

                out.write(f.read())

    return {"status":"assembled"}

@app.route("/download")
def download():

    token=request.headers.get("token")

    if not verify_token(token):
        return {"error":"unauthorized"}

    logging.info("file downloaded")

    return send_file(FINAL_FILE,as_attachment=True)

if __name__=="__main__":
    if os.path.exists("cert.pem"):
        app.run(host="0.0.0.0",port=5000,ssl_context=("cert.pem","key.pem"))
    else:
        app.run(port=5000)
