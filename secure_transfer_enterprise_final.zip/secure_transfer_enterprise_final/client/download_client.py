﻿import requests
from crypto_utils import decrypt,verify_hmac

token=requests.get("http://127.0.0.1:5000/login").json()["token"]

requests.get("http://127.0.0.1:5000/assemble")

r=requests.get("http://127.0.0.1:5000/download",headers={"token":token})

data=r.content

enc=data[:-32]
tag=data[-32:]

if verify_hmac(enc,tag):

    decrypted=decrypt(enc)

    open("recovered.txt","wb").write(decrypted)

    print("Integrity verified")
    print("Secure download complete")

else:

    print("Integrity check failed")
