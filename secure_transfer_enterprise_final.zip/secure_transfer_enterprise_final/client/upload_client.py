﻿import requests,hashlib
from crypto_utils import encrypt,generate_hmac

CHUNK_SIZE=512*1024

token=requests.get("http://127.0.0.1:5000/login").json()["token"]

data=open("test.txt","rb").read()

print("File SHA256:",hashlib.sha256(data).hexdigest())

enc=encrypt(data)

tag=generate_hmac(enc)

payload=enc+tag

chunks=[payload[i:i+CHUNK_SIZE] for i in range(0,len(payload),CHUNK_SIZE)]

for i,chunk in enumerate(chunks):

    files={"file":("chunk",chunk)}

    r=requests.post(
        "http://127.0.0.1:5000/upload",
        files=files,
        params={"chunk":i},
        headers={"token":token}
    )

    print(r.json())

print("Upload finished")
