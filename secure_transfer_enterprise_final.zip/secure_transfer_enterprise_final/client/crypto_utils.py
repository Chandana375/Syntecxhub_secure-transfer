﻿from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os,hmac,hashlib

KEY=b'12345678901234567890123456789012'

def encrypt(data):
    aes=AESGCM(KEY)
    nonce=os.urandom(12)
    enc=aes.encrypt(nonce,data,None)
    return nonce+enc

def decrypt(data):
    aes=AESGCM(KEY)
    nonce=data[:12]
    return aes.decrypt(nonce,data[12:],None)

def generate_hmac(data):
    return hmac.new(KEY,data,hashlib.sha256).digest()

def verify_hmac(data,tag):
    return hmac.compare_digest(generate_hmac(data),tag)
